package com.example.oussama_achraf.mplrss;

import android.content.ClipData;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.example.oussama_achraf.mplrss.XMLParsingUtils.ItemXml;
import com.example.oussama_achraf.mplrss.XMLParsingUtils.XmlAnalyser;
import com.example.oussama_achraf.mplrss.database.AccesData;

import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.List;

public class RssPlayer extends AppCompatActivity {

    private RecyclerView rssFluxView = null;
    private TextView principalTitle = null;
    private TextView principalDescription = null;

    private ArrayList<ItemXml> items = null;
    private AdapterRssFluxRecyclerViewer myAdapter = null;

    private String httpLink = null;

    private AccesData accesData = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rss_player);

        this.accesData = new AccesData(this);

        rssFluxView = findViewById(R.id.recylerViewRss);
        principalDescription = findViewById(R.id.descriptionRss);
        principalTitle = findViewById(R.id.titleRss);

        /**
         * bind the Rss data into into this activity
         */
        Intent intent = getIntent();
        String mode = intent.getStringExtra("mode");

        if(mode.equals("offline")){

            int id = intent.getIntExtra("idOffline",0);
            List<ItemXml> listItems = accesData.getRssData(id);
            this.principalTitle.setText(intent.getStringExtra("titleOffline"));
            this.principalDescription.setText(intent.getStringExtra("descriptionOffline"));
            this.rssFluxView.setLayoutManager(new LinearLayoutManager(this));
            this.myAdapter = new AdapterRssFluxRecyclerViewer(this,listItems,android.R.layout.simple_list_item_1);
            this.rssFluxView.setAdapter(myAdapter);

        }else if(mode.equals("online")){
            httpLink = intent.getStringExtra("httpAddress");
            getFluxRssData(intent.getStringExtra("pathXmlFile"));
            this.rssFluxView.setLayoutManager(new LinearLayoutManager(this));
            this.myAdapter = new AdapterRssFluxRecyclerViewer(this,items,android.R.layout.simple_list_item_1);
            this.rssFluxView.setAdapter(myAdapter);
        }



        // end bindig --


    }

    public void getFluxRssData(String pathXmlFile){
        Document document = XmlAnalyser.parseXml(pathXmlFile);

        this.items = XmlAnalyser.getItemsArray(document);

        String titlePrincipalRss = XmlAnalyser.getPrincipalTitle(document);
        String descriptionPrincipalRss = XmlAnalyser.getPrincipalDescription(document);

        this.principalTitle.setText(titlePrincipalRss);
        this.principalDescription.setText(descriptionPrincipalRss);

        /**
         * now we have our document
         * and the items array and the title and description
         * so we have to save them to the database and remove the file from the device
         */

        /*
        * insert to db
        * */

        Log.d("recy","link is ???? -> "+httpLink);
        /**
         * test -1 error already exist
         */
        int id_1 = accesData.insertRssLink(httpLink, titlePrincipalRss, descriptionPrincipalRss,"");

        if(id_1 != -1){
            for(int i=0; i<items.size() ; i++){
                accesData.insertRssData(items.get(i).getLink(),
                        items.get(i).getTitle(),
                        items.get(i).getDescription());
            }
            Toast toast = Toast.makeText(this,"data is save",Toast.LENGTH_LONG);
            toast.show();
        }else{
            Toast toast = Toast.makeText(this,"data is not save it already exist  ",Toast.LENGTH_LONG);
            toast.show();
        }


    }
}
