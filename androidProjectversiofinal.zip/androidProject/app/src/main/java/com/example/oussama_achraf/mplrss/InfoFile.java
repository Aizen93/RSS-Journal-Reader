package com.example.oussama_achraf.mplrss;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.oussama_achraf.mplrss.XMLParsingUtils.ItemXml;
import com.example.oussama_achraf.mplrss.XMLParsingUtils.XmlAnalyser;

import org.w3c.dom.Document;

import java.util.ArrayList;

public class InfoFile extends AppCompatActivity {

    private TextView infoXmlFilePath = null;
    private TextView infoXmlFileSize = null;
    private TextView infoXmlFileStatus = null;

    private String pathXmlFile = null;

    private String httpLink = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_file);

       infoXmlFilePath = findViewById(R.id.textViewInfoPath);
       infoXmlFileSize = findViewById(R.id.textViewInfoSize);
       infoXmlFileStatus = findViewById(R.id.textViewInfoStatus);



       Intent intent = getIntent();
       String path = intent.getStringExtra("pathFile");
       int size = intent.getIntExtra("sizeFile", 0);
       int status = intent.getIntExtra("statusFile",0);

       this.httpLink = intent.getStringExtra("httpAddress");
       Log.d("recy",httpLink);
       this.pathXmlFile = path;
       showDetails(path,size,status);
    }

    public void showDetails(String path,int size, int status){
        String statusString = "Unknown";
        switch(status){
            case 1: statusString="pending";break;
            case 2: statusString="running";break;
            case 4: statusString="paused";break;
            case 8: statusString="sucessfuly downloaded";break;
            case 16: statusString="failer !";break;

        }

        String details = "The file is at \n path : "+path +" \n"
                +"size is : "+size +" status is :"+statusString +"\n";
        infoXmlFilePath.setText("Path : "+path);
        infoXmlFileSize.setText("Size : "+size+"octet");
        infoXmlFileStatus.setText("Status : "+statusString);
    }
    public void processXML(View view){
        Intent intentRssPlayer = new Intent(this,RssPlayer.class);

        intentRssPlayer.putExtra("pathXmlFile",pathXmlFile);
        intentRssPlayer.putExtra("httpAddress",httpLink);
        intentRssPlayer.putExtra("mode","online");


        startActivity(intentRssPlayer);

        //Log.d("items","title : "+titlePrincipalRss);
        //Log.d("items","description :"+descriptionPrincipalRss);

    }
}
