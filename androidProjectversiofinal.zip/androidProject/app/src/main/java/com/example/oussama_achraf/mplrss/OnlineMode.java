package com.example.oussama_achraf.mplrss;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.URLUtil;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.oussama_achraf.mplrss.XMLParsingUtils.ItemXml;
import com.example.oussama_achraf.mplrss.XMLParsingUtils.RssElement;
import com.example.oussama_achraf.mplrss.XMLParsingUtils.XmlDownloader;
import com.example.oussama_achraf.mplrss.database.AccesData;

import java.util.ArrayList;
import java.util.List;

public class OnlineMode extends AppCompatActivity {
    private EditText editTextLink = null;
    private ProgressBar progressBar = null;
    private TextView textViewLoading = null;
    private Button cancelButton = null;

   // private ListView historylinksView = null;
    private RecyclerView historylinksView = null;

    private AdapterRssFluxRecyclerHistoryViewer myAdapter = null;

    private AccesData accesData = null;
    private int showHistory = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_online_mode);

        editTextLink = findViewById(R.id.editTextLink);
        progressBar = findViewById(R.id.progressBar);
        textViewLoading = findViewById(R.id.textViewLoading);
        cancelButton = findViewById(R.id.cancelButton);

        historylinksView = findViewById(R.id.historyViewer);

        this.accesData = new AccesData(this);

        cancelButton.setVisibility(View.GONE);
        //historylinksView.setVisibility(View.GONE);

        // just to not start keyboard each time at focus
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        XmlDownloader.checkInternet(this);
        XmlDownloader.checkDiskPermission(this);


        // HistoryDataGetter.fillTheHistoryLinks(this,historylinksView,editTextLink);
        fillHistoryViewer(historylinksView);

    }
    public void fillHistoryViewer(RecyclerView recyclerView){
        this.historylinksView.setLayoutManager(new LinearLayoutManager(this));

        /*
        get data from database lst of links
         */


        List<RssElement> rssitems = accesData.getAllRssLink();

        this.myAdapter = new AdapterRssFluxRecyclerHistoryViewer(this,rssitems,android.R.layout.simple_list_item_1);
        this.historylinksView.setAdapter(myAdapter);



    }

    public void downloadXmlFile(View view){
        // download the xml file here
        String link = editTextLink.getText().toString();

        if(link.isEmpty()){
            Toast t = Toast.makeText(this,"please type some valid link",Toast.LENGTH_LONG);
            t.show();
            return;
        }
        if(URLUtil.isHttpsUrl(link) || URLUtil.isHttpUrl(link) ) {
            cancelButton.setVisibility(View.VISIBLE);
            XmlDownloader.download(this,link,progressBar,textViewLoading,cancelButton);
        }else{
            Toast t = Toast.makeText(this,"please type some valid http/https url",Toast.LENGTH_LONG);
            t.show();
        }

    }
    public void hideShowHistory(View view){
        if(showHistory == 1 ){
            historylinksView.setVisibility(View.GONE);
            showHistory = 0;
        }else{
            historylinksView.setVisibility(View.VISIBLE);
            showHistory = 1;
        }
    }
    public void goSearchActivity(View view){
        startActivity(new Intent(this,SearchActivity.class));
    }

}
