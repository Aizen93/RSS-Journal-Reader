package com.example.oussama_achraf.mplrss;

import android.app.Activity;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.oussama_achraf.mplrss.XMLParsingUtils.ItemXml;
import com.example.oussama_achraf.mplrss.database.AccesData;

import java.util.List;

public class SearchActivity extends AppCompatActivity {

    private EditText search;
    private TextView results;
    private ImageView apply;
    private RecyclerView recyclerView;
    private AdapterRssFluxRecyclerViewer myAdapter = null;

    private AccesData accesData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        final Activity ac = this;
        final Context ct = this.getBaseContext();

        this.accesData = new AccesData(this);

        this.search = findViewById(R.id.editText);
        this.results = findViewById(R.id.results);
        this.apply = findViewById(R.id.apply);
        this.recyclerView = findViewById(R.id.recyclerView);

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        this.apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("Show", "Apply clicked");
                List<ItemXml> listItems = accesData.RechercheMot(search.getText().toString());
                if(listItems.isEmpty()) results.setText("No results found...");
                else {
                    results.setText("Results... " + listItems.size() + " items found !");
                    recyclerView.setLayoutManager(new LinearLayoutManager(ct));
                    myAdapter = new AdapterRssFluxRecyclerViewer(ac, listItems, android.R.layout.simple_list_item_1);
                    recyclerView.setAdapter(myAdapter);
                    search.setText("");
                }
            }
        });

    }
}